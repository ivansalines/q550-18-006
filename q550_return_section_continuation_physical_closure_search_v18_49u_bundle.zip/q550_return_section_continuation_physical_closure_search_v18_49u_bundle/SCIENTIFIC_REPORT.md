# v18.49u — Return-Section Continuation & Physical Closure Search

## Classification
NO_PHYSICAL_CLOSURE_IN_EXPLORED_RETURN_SECTION_DOMAIN

**This is a finite numerical search, not a global no-closure theorem or a material-memory certificate.**

## Genuine physical integrations
- Forward 11D integrations: 2
- Return 11D integrations: 22
- Optimized sections: 66
- Strict closed candidates: 0
- Evaluation failures: 0

## Minimum configuration gap
- κ0: original; ramp: 0.12
- Gap: 0.0871547223488; at forward t=0.70987780, return t=0.32227784
- Velocity mismatch at same section: 0.244461369152

## Minimum joint full reversed-state gap
- κ0: original; ramp: 0.12
- Joint gap: 0.18104276823; configuration=0.0891669888661; velocity=0.15756183556
- Energy difference: -0.00188932990942
- Lifted phase offset (turns): 0.0125410591761
- Projector gap (if selected for 10D): 0.4910948431412535

## Interpretation
Optimization changes the two observation times and the ramp duration across a finite sampled range, but never adjusts the physical state or inserts a canonical endpoint connector.
Configuration and reverse-velocity minima are different criteria; energy and common-frame projector comparisons are independent gates.
The velocity reversal at the turning point is externally imposed. No match is automatically a spontaneous physical reversal.
No strict closure means no physical material-memory conclusion; a strict candidate would still require convergence and a separate causal memory test.

## Methodological boundaries
- A finite coarse-to-adaptive duration search; not proof that a return section cannot exist elsewhere.
- Forward/return both genuine Q550 11D integrations under an externally imposed velocity reversal; not spontaneous time reversal.
- The search optimizes two section times at each duration; closure may lie outside their declared windows.
- Nearest configuration, nearest velocity and nearest full reversed state are separate minima and do not imply closure.
- Mechanical-energy matching is checked as an independent gate with full original work/damping/source ledger.
- Common-frame spectral projectors are computed only for selected best joint candidates; missing projectors never count as matched.
- Wrapped phase is a modulo-2pi matching convention; unwrapped lifted phase difference is reported separately.
- A numerical closed candidate alone would NOT certify physical material memory or physical torsion.
- No interval enclosure or global continuation theorem is established.

## Search-boundary audit

- 46/66 optimized candidate sections touch a declared search boundary.
- The smallest **joint** full-state mismatch is **0.181042768** at κ0=original, r=0.120000, return phase q=0.100000. This q is the **lower boundary**, not a discovered interior minimum.
- The smallest *configuration-only* mismatch is **0.087154722** at (forward t=0.70987780, return t=0.32227784); its simultaneous reverse-velocity mismatch is 0.244461369.
- To protect the meaning of physical closure, the search excludes the immediate turnaround by imposing q≥0.10. Extending toward q=0 would approach the externally imposed flip and must be analyzed as a separate negative control.
- A smaller mismatch at a domain edge is NOT a proof that the dynamics contains a closing branch; it may instead reflect the artificial geometry of the experiment and its selected windows.
